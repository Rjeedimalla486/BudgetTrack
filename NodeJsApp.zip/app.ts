import express, { json } from 'express';
import { createServer } from "http";
const Server = require("socket.io");
import { Socket } from "socket.io";
import io from 'socket.io-client';
const request = require('request')

const app = express();
const httpServer = createServer(app);
app.use(json());


const port = 3000;

var count = 0;

let socket = null;

const appServer = app.listen(port, () => {
    console.log(`Timezones by location application is running on port ${port}.`);
});

const ioserver = new Server(appServer, {
    pingInterval: 120000,
  
  });

  var nsp = ioserver.of('/my-namespace');
  nsp.on('connection', function(socket){
    console.log('someone connected');
    nsp.emit('hi', 'Hello everyone!');
 });

 nsp.on('hi', (socket) => {
    socket.log(socket);
 })

app.get('/open', (req, res) => {
    console.log("this is the first");

    const reqBody = {
        "authentication": "NWJia1BQRjUwNE9TUXFjSUlPZE1wV1dCaWlzYTpWbkdHN2dFaGw0R0xldmQyVlZKZjFYMGJrNWth"
    };

    let header = {
        "Content-Type": "application/json",
        "Accept": "*",
    };

    const options = {
        url: 'https://wstreamer.kotaksecurities.com/feed/auth/token',
        json: {
            authentication: "NWJia1BQRjUwNE9TUXFjSUlPZE1wV1dCaWlzYTpWbkdHN2dFaGw0R0xldmQyVlZKZjFYMGJrNWth"
        }
    };



    const rr = request.post(options, (err: any, res: any, body: any) => {

        let accessToken = body?.result?.token;
        let h = {
            Authorization: "Bearer " + accessToken
        }

        console.log(accessToken);

        socket = io("https://wstreamer.kotaksecurities.com", {
            multiplex: true,
            path: "/feed",
            reconnection: true,
            autoConnect: false,
            requestTimeout: 0,
            reconnectionAttempts: 2,
            transports: ["websocket"],
            extraHeaders: {
                "Authorization": "Bearer " + accessToken
            },
            withCredentials: true,
            upgrade: true,
            secure: false,
            rememberUpgrade: true

        });

        socket.on("connect", () => {
            console.log("Connected BRO --");
            let input_tokens = "891";
            socket.emit('pageload', { 'inputtoken': input_tokens })
        });

        socket.on("getdata", (data: any) => {
            console.log("+++ ",count++, data);
            nsp.emit('hi', data);
            
        });

        socket.on("error", (err: any) => {
            console.log("ERror Bro ", err);
        });

        socket.on("connect_error", (error: any) => {
            console.log("ERror MAMA ", error);
        });

        socket.open();

    });

    req.on("error", (error: any) => {
        res.send(error);
        
    });

    res.sendFile('C:/Users/rajes/IdeaProjects/Kotak-JS/NodeJSApp/index.html');

});

app.get("/close", (req, res) => {
    console.log("Closing...");
    socket.disconnect();
    res.send("Mama Closed....");
});

app.get("/tt", (req, res) => {
    res.sendFile('C:/Users/rajes/IdeaProjects/Kotak-JS/NodeJSApp/index.html');
});


