
const express = require("express");
const request = require('request');
const { Manager, Socket } = require("socket.io-client");
const io = require("socket.io-client");

const app = express();

app.get("/temp", (rr, rs) => {

  const reqBody = {
    "authentication": "NWJia1BQRjUwNE9TUXFjSUlPZE1wV1dCaWlzYTpWbkdHN2dFaGw0R0xldmQyVlZKZjFYMGJrNWth"
  };

  let header = {
    "Content-Type": "application/json",
    "Accept": "*",
  };

  const options = {
    url: 'https://wstreamer.kotaksecurities.com/feed/auth/token',
    json: {
      authentication: "NWJia1BQRjUwNE9TUXFjSUlPZE1wV1dCaWlzYTpWbkdHN2dFaGw0R0xldmQyVlZKZjFYMGJrNWth"
    }
  };



  const req = request.post(options, (err, res, body) => {

    let accessToken = body?.result?.token;
    let h = {
      Authorization: "Bearer " + accessToken
    }

    console.log(accessToken);

    const manager = new Manager("https://wstreamer.kotaksecurities.com", {
      multiplex: true,
      path: "/feed",
      reconnection: true,
      autoConnect: false,
      requestTimeout: 0,
      reconnectionAttempts: 2,
      transports: ["websocket"],
      extraHeaders: {
        "Authorization": "Bearer " + accessToken
      },
      withCredentials: true,
      upgrade: true,
      secure: false,
      rememberUpgrade: true

    });

    let socket = manager.socket("/feed", {
      auth: {
        "Authorization": "Bearer " + accessToken
      }
    }); // admin namespace


    manager.on("connect", () => {
      console.log("Connected BRO --", manager.listeners);
      input_tokens = "891";
      socket.emit('pageload', { 'inputtoken': input_tokens })
    });

    manager.on("getdata", (data) => {
      console.log("+++ ", data);
    })


    manager.on("connect_error", (error) => {
      console.log("ERror MAMA ", error);
    });

    manager.onopen();

    manager.onerror()

    manager.connect((err) => {
      if (err) {
        console.log("-----")
        console.log(err);
      } else {
        // the connection was successfully established
        console.log("Connected BRO");
        input_tokens = "891";
        manager.emit('pageload', { 'inputtoken': input_tokens })
      }
    });


  });

  req.on('error', error => {
    console.error(error);
  });

  //req.end();


  rs.send("<h1> Hello World </h1>");

});


app.get("/open", (rr, rs) => {

  const reqBody = {
    "authentication": "NWJia1BQRjUwNE9TUXFjSUlPZE1wV1dCaWlzYTpWbkdHN2dFaGw0R0xldmQyVlZKZjFYMGJrNWth"
  };

  let header = {
    "Content-Type": "application/json",
    "Accept": "*",
  };

  const options = {
    url: 'https://wstreamer.kotaksecurities.com/feed/auth/token',
    json: {
      authentication: "NWJia1BQRjUwNE9TUXFjSUlPZE1wV1dCaWlzYTpWbkdHN2dFaGw0R0xldmQyVlZKZjFYMGJrNWth"
    }
  };



  const req = request.post(options, (err, res, body) => {

    let accessToken = body?.result?.token;
    let h = {
      Authorization: "Bearer " + accessToken
    }

    console.log(accessToken);

    let socket = io("https://wstreamer.kotaksecurities.com", {
      multiplex: true,
      path: "/feed",
      reconnection: true,
      autoConnect: false,
      requestTimeout: 0,
      reconnectionAttempts: 2,
      transports: ["websocket"],
      extraHeaders: {
        "Authorization": "Bearer " + accessToken
      },
      withCredentials: true,
      upgrade: true,
      secure: false,
      rememberUpgrade: true

    });

    socket.on("connect", () => {
      console.log("Connected BRO --");
      input_tokens = "891";
      socket.emit('pageload', { 'inputtoken': input_tokens })
    });

    socket.on("getdata", (data) => {
      console.log("+++ ", data);
    });

    socket.on("error", (err) => {
      console.log("ERror Bro ", err);
    });

    socket.on("connect_error", (error) => {
      console.log("ERror MAMA ", error);
    });

    socket.open();
    exports.globalSocket = socket;

  });

  req.on('error', error => {
    console.error(error);
  });

  //req.end();


  rs.send("<h1> The LEGEND </h1>");

});


app.get("/close", (rr, rs) => {
  
  exports.globalSocket.disconnect();
  rs.send("<h1> The CLOSED </h1>");
});

app.listen(3000, () => {
  console.log("Listening to port 3000");
});



