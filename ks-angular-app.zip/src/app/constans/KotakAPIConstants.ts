export class KotakApiConstants {
    static readonly CONSUMER_KEY = "5bbkPPF504OSQqcIIOdMpWWBiisa";
    static readonly CONSUMER_SECRET = "VnGG7gEhl4GLevd2VVJf1X0bk5ka";
    static readonly ACCESS_TOKEN = "50402cd8-5258-3c0f-8d4e-c12b389995a4";
    static readonly IP="127.0.0.1";
    static readonly USERID = "RJ8061992";
    static readonly HOST = "https://ctradeapi.kotaksecurities.com/apim";
    static readonly PASSWORD="R@j37411";
    static readonly WS_HTTP = "https://wstreamer.kotaksecurities.com/feed/auth/token";
    static readonly WSS = "wss://wstreamer.kotaksecurities.com/feed/?transport=websocket&EIO=4";

    static readonly URL_SYMBOLS = "https://preferred.kotaksecurities.com/security/production/TradeApiInstruments_Cash_08_09_2022.txt";
    static readonly URL_FNO_SYMBOLS = "https://preferred.kotaksecurities.com/security/production/TradeApiInstruments_Cash_08_09_2022.txt";
    static readonly KS_SYMBOLS = "/security/production/TradeApiInstruments_Cash_08_09_2022.txt";
}
