import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {KotakApiConstants} from '../constans/KotakAPIConstants';
import {webSocket, WebSocketSubject} from 'rxjs/webSocket';
import {io, ManagerOptions, Socket} from "socket.io-client";
import {Manager} from "socket.io-client";
import {BehaviorSubject} from "rxjs";


@Injectable({
  providedIn: 'root'
})
export class KsWebsocketService {

  socket!: Socket;

  tempRxjs: BehaviorSubject<any>= new BehaviorSubject<any>("First Time");


  myWebSocket: WebSocketSubject<any> = webSocket('wss://wstreamer.kotaksecurities.com/feed/?transport=websocket&EIO=4');

  constructor(public httpClient: HttpClient) {

  }

  socketIo(instrumentToken?: string) {


    this.socket = io("http://localhost:3000/my-namespace", {
      transports: ['websocket'],
      path: '/socket.io',
      upgrade: true,
      rememberUpgrade: true,
      autoConnect: false,
      reconnectionAttempts: 1,
      timeout: 60000
    }).open();

    // this.socket.on("connect", () => {
    //   console.log("Connected Client BRO CLIENT");
    //   this.tempRxjs.next("CONNECTED");
    // });

    this.socket.on("hi", (data) => {
      console.log("Connected Client BRO --", data);
      this.tempRxjs.next("data");

    });



    //this.socket.open();



  }

  subscribe() {
    console.log("COMPONENT")
    const body = {
      "authentication": "NWJia1BQRjUwNE9TUXFjSUlPZE1wV1dCaWlzYTpWbkdHN2dFaGw0R0xldmQyVlZKZjFYMGJrNWth"
    }

    let h = {
      "Content-Type": "application/json",
      "Control-Allow-Origin": "*",
      "Accept": "*",
      //"Host": "wstreamer.kotaksecurities.com",
      "Access-Control-Allow-Origin": "http://localhost:4200",
      "Access-Control-Allow-Methods": "POST",
      //"Referer": "https://wstreamer.kotaksecurities.com"
    }

    let headers: HttpHeaders = new HttpHeaders(h);

    let accessToken: string = '';

    //   let socket$: WebSocketSubject<any> = webSocket({
    //     url: 'wss://ws.finnhub.io?token=bsr37a748v6tucpfplbg',
    //     openObserver: {
    //     next: () => {
    //       socket$.next({'type':'subscribe', 'symbol': 'BINANCE:BTCUSDT'});
    //     }
    //   },
    // });

    let successHandler = (response: any) => {
      accessToken = response['result']['token'];
      let h = {
        "Authorization": "Bearer " + accessToken
      }

      console.log(h);


      this.httpClient.get<any>("https://wstreamer.kotaksecurities.com/feed?transport=websocket&EIO=4", {headers: h}).subscribe({
        next: (response: any) => {
          console.log(response);
          let ws = new WebSocket("wss://wstreamer.kotaksecurities.com/feed/?transport=websocket&EIO=4");

          ws.onopen = function () {

            // Web Socket is connected, send data using send()
            ws.send("Message to send");
            alert("Message is sent...");
          };

          ws.onmessage = function (evt) {
            var received_msg = evt.data;
            alert("Message is received...");
          };

          ws.onclose = function () {

            // websocket is closed.
            alert("Connection is closed...");
          };
        },
        error: (e) => console.error(e),
        complete: () => console.info('complete')
      })
      /* if ("WebSocket" in window) {
        let ws = new WebSocket("https://wstreamer.kotaksecurities.com/feed/?transport=websocket&EIO=4");

        ws.onopen = function () {

          // Web Socket is connected, send data using send()
          ws.send("Message to send");
          alert("Message is sent...");
        };

        ws.onmessage = function (evt) {
          var received_msg = evt.data;
          alert("Message is received...");
        };

        ws.onclose = function () {

          // websocket is closed.
          alert("Connection is closed...");
        };
      } else {

        // The browser doesn't support WebSocket
        alert("WebSocket NOT supported by your Browser!");
      } */


    }

    this.httpClient.post<any>(KotakApiConstants.WS_HTTP, body, {headers: headers}).subscribe({
      next: successHandler,
      error: (e) => console.error(e),
      complete: () => console.info('complete')
    })
  }
}
