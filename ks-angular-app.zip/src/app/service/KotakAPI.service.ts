import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { KotakApiConstants } from '../constans/KotakAPIConstants';
import converter from 'csvtojson'
import { KotakSymbol } from '../pojo/KotakSymbol';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class KotakAPIService {

  symbols: BehaviorSubject<KotakSymbol[]> = new BehaviorSubject<Array<KotakSymbol>>([]);
  symbolsObservable = this.symbols.asObservable();

  constructor(public httClient: HttpClient) {
  }

  public getSymbols(): Observable<any> {
    return this.httClient.get(KotakApiConstants.KS_SYMBOLS, { responseType: 'text' as 'text' });

  }

  loadSymbols() {
    if (_.isEmpty(this.symbols.getValue())) {
      this.getSymbols().subscribe(
        {
          next: data => {
            converter({
              noheader: false,
              trim: true,
              delimiter: '|'
            })
            .fromString(data)
            .then((jsonData: KotakSymbol[]) => {
              this.symbols.next(jsonData);
            });
          }
        });
    } else {
      this.symbols.next(this.symbols.getValue())
    }

  }
}
