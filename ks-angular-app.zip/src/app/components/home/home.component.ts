import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { KotakSymbol } from 'src/app/pojo/KotakSymbol';
import { KotakAPIService } from 'src/app/service/KotakAPI.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, AfterViewInit {

  symbolData: MatTableDataSource<KotakSymbol> = new MatTableDataSource();
  displayedColumns: string[] = ["instrumentToken","instrumentName","name","lastPrice","lotSize","instrumentType","segment","exchange","exchangeToken"];
  searchText: string = "";

  @ViewChild("paginator")
  paginator!: MatPaginator

  constructor(public kotakApiService: KotakAPIService) {
    this.kotakApiService.symbols.subscribe(symbols => {
      this.symbolData.data = symbols;
    })


  }

  ngOnInit() {
    this.symbolData.paginator = this.paginator;
  }

  ngAfterViewInit(): void {
    this.symbolData.paginator = this.paginator;
  }

  onClick(){
    this.kotakApiService.loadSymbols();
  }

  filterGrid() {
    this.symbolData.filter = this.searchText.trim().toLowerCase();

    if(this.symbolData.paginator){
      this.symbolData.paginator.firstPage();
    }
  }

}
