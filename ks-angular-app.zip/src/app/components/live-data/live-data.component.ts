import { Component, OnInit } from '@angular/core';
import { KsWebsocketService } from 'src/app/service/ks-websocket.service';

@Component({
  selector: 'app-live-data',
  templateUrl: './live-data.component.html',
  styleUrls: ['./live-data.component.scss']
})
export class LiveDataComponent implements OnInit {
  InstrumentTokenInput: string = '891';


  constructor(public ksWebsocketService: KsWebsocketService) { }

  ngOnInit(): void {
    this.ksWebsocketService.tempRxjs.subscribe({
      next: value => {
        console.log("vaulue = ",value);
      },
      error: (e) => console.error("Error mam",e),
      complete : () => console.info('complete')
    })
  }

  onClickLoadLiveData(){
    this.ksWebsocketService.socketIo(this.InstrumentTokenInput);
  }

}
