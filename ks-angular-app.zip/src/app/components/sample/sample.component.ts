import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import {ThemePalette} from '@angular/material/core';
import { map, Observable, startWith } from 'rxjs';
import { KsWebsocketService } from 'src/app/service/ks-websocket.service';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.scss']
})
export class SampleComponent implements OnInit {

  links = ['First', 'Second', 'Third'];
  activeLink = this.links[0];

  constructor(public ksWebsocketService: KsWebsocketService){

  }

  @Input()
  myControl = new FormControl('');
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions: Observable<string[]> = new Observable();


  addLink() {
    this.links.push(`Link ${this.links.length + 1}`);
  }

  ngOnInit(): void {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value || '')),
    );


    
  }

  openSocket(){
    this.ksWebsocketService.socketIo();
  }

  
  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

}
