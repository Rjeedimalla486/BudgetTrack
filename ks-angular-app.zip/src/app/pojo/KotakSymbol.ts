export class KotakSymbol {

    instrumentToken!: number;
    instrumentName!: string;
    name!: string;
    lastPrice!: number;
    expiry!: number;
    strike!: number;
    tickSize!: number;
    lotSize!: number;
    instrumentType!: string;
    segment!: string;
    exchange!: string;
    isin!: string;
    multiplier!: number;
    exchangeToken!: number;
    OptionType!: string;
    
}
